//
//  SFApplication.h
//  SalesforceSDK
//
//  Created by Kevin Hawkins on 5/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SFApplication : UIApplication

@property (nonatomic, readonly) NSDate *lastEventDate;

@end
